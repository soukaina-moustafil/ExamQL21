package com.example.ExamQL21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamQl21Application {

	public static void main(String[] args) {
		SpringApplication.run(ExamQl21Application.class, args);
	}

}
